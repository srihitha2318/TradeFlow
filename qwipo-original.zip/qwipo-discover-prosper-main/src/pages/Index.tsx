import { useState } from "react";
import { LandingPage } from "@/pages/landing-page";
import { UserTypeSelection } from "@/components/auth/user-type-selection";
import { LoginForm } from "@/components/auth/login-form";
import { RegisterForm } from "@/components/auth/register-form";
import { CustomerDashboard } from "@/components/dashboard/customer-dashboard";
import { SupplierDashboard } from "@/components/dashboard/supplier-dashboard";

type AppState = "landing" | "userType" | "login" | "register" | "dashboard";
type UserType = "customer" | "supplier" | null;

const Index = () => {
  const [currentState, setCurrentState] = useState<AppState>("landing");
  const [userType, setUserType] = useState<UserType>(null);

  const handleGetStarted = () => {
    setCurrentState("userType");
  };

  const handleUserTypeSelection = (type: "customer" | "supplier") => {
    setUserType(type);
    setCurrentState("login");
  };

  const handleLogin = () => {
    setCurrentState("dashboard");
  };

  const handleRegister = () => {
    setCurrentState("dashboard");
  };

  const handleBack = () => {
    switch (currentState) {
      case "userType":
        setCurrentState("landing");
        break;
      case "login":
      case "register":
        setCurrentState("userType");
        break;
      case "dashboard":
        setCurrentState("landing");
        setUserType(null);
        break;
      default:
        setCurrentState("landing");
    }
  };

  const renderContent = () => {
    switch (currentState) {
      case "landing":
        return <LandingPage onGetStarted={handleGetStarted} />;
      case "userType":
        return (
          <UserTypeSelection 
            onSelectUserType={handleUserTypeSelection} 
            onBack={handleBack}
          />
        );
      case "login":
        return (
          <LoginForm 
            userType={userType!} 
            onBack={handleBack}
            onLogin={handleLogin}
          />
        );
      case "register":
        return (
          <RegisterForm 
            userType={userType!} 
            onBack={handleBack}
            onRegister={handleRegister}
          />
        );
      case "dashboard":
        return userType === "customer" ? (
          <CustomerDashboard onBack={handleBack} />
        ) : (
          <SupplierDashboard onBack={handleBack} />
        );
      default:
        return <LandingPage onGetStarted={handleGetStarted} />;
    }
  };

  return renderContent();
};

export default Index;
