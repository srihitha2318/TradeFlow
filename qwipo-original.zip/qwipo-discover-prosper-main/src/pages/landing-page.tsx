import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Users, ShoppingBag, TrendingUp, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import heroBackground from "@/assets/marketplace-hero-bg.jpg";

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  const [currentFeedback, setCurrentFeedback] = useState(0);

  const stats = [
    { label: "Total Buyers", value: "15,847", icon: Users, trend: "+12%" },
    { label: "Total Sellers", value: "3,254", icon: ShoppingBag, trend: "+8%" },
    { label: "Website Rating", value: "4.8/5", icon: Star, trend: "+0.2" },
    { label: "Monthly Transactions", value: "125K", icon: TrendingUp, trend: "+15%" }
  ];

  const feedbacks = [
    {
      name: "Rajesh Kumar",
      company: "Kumar Electronics",
      rating: 5,
      comment: "Trade Flow has revolutionized our bulk purchasing. The AI recommendations saved us 30% on procurement costs.",
      type: "buyer"
    },
    {
      name: "Priya Sharma",
      company: "Sharma Textiles",
      rating: 5,
      comment: "As a supplier, Trade Flow connected us with 200+ new customers in just 3 months. Excellent platform!",
      type: "supplier"
    },
    {
      name: "Mohammed Ali",
      company: "Ali Food Products",
      rating: 4,
      comment: "The bulk ordering system is seamless. We increased our order volume by 40% with better supplier discovery.",
      type: "buyer"
    },
    {
      name: "Anjali Patel",
      company: "Patel Manufacturing",
      rating: 5,
      comment: "Trade Flow's verified supplier network gave us confidence to expand our business nationwide.",
      type: "supplier"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Hero Section */}
      <section 
        className="relative py-20 px-4 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBackground})` }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Welcome to <span className="text-accent">Trade Flow</span>
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            The ultimate B2B marketplace connecting suppliers and customers with intelligent product recommendations and seamless bulk trading solutions.
          </p>
          
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 bg-accent hover:bg-accent/90"
            onClick={onGetStarted}
          >
            Get Started <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <stat.icon className="h-10 w-10 mx-auto mb-4 text-primary" />
                  <h3 className="text-3xl font-bold text-foreground mb-2">{stat.value}</h3>
                  <p className="text-muted-foreground mb-2">{stat.label}</p>
                  <Badge variant="secondary" className="text-green-600">
                    {stat.trend}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Customer & Supplier Feedback Carousel */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              What Our Community Says
            </h2>
            <p className="text-muted-foreground text-lg">
              Real feedback from buyers and suppliers on Trade Flow
            </p>
          </div>

          <div className="relative max-w-4xl mx-auto">
            <Card>
              <CardContent className="p-8">
                <div className="flex overflow-hidden">
                  <div 
                    className="flex transition-transform duration-300 ease-in-out"
                    style={{ transform: `translateX(-${currentFeedback * 100}%)` }}
                  >
                    {feedbacks.map((feedback, index) => (
                      <div key={index} className="w-full flex-shrink-0">
                        <div className="text-center">
                          <div className="flex justify-center mb-4">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-5 w-5 ${i < feedback.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                              />
                            ))}
                          </div>
                          <blockquote className="text-lg text-muted-foreground mb-6 italic">
                            "{feedback.comment}"
                          </blockquote>
                          <div className="flex items-center justify-center gap-4">
                            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                              <span className="text-primary-foreground text-lg font-bold">
                                {feedback.name.charAt(0)}
                              </span>
                            </div>
                            <div className="text-left">
                              <p className="font-semibold text-foreground">{feedback.name}</p>
                              <p className="text-sm text-muted-foreground">{feedback.company}</p>
                              <Badge variant={feedback.type === 'buyer' ? 'default' : 'secondary'} className="mt-1">
                                {feedback.type === 'buyer' ? 'Buyer' : 'Supplier'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-center gap-2 mt-6">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentFeedback(prev => 
                      prev === 0 ? feedbacks.length - 1 : prev - 1
                    )}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentFeedback(prev => 
                      prev === feedbacks.length - 1 ? 0 : prev + 1
                    )}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Why Choose Trade Flow?
            </h2>
            <p className="text-muted-foreground text-lg">
              Powerful features designed for modern B2B commerce
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <ShoppingBag className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>Bulk Trading</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Seamless bulk ordering with competitive pricing and verified suppliers
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <TrendingUp className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>AI Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Smart product recommendations based on your business needs and history
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>Verified Network</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Connect with verified suppliers and customers across India
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-primary">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Ready to Transform Your Business?
          </h2>
          <p className="text-primary-foreground/90 text-lg mb-8">
            Join thousands of successful businesses on Trade Flow
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            className="text-lg px-8 py-6"
            onClick={onGetStarted}
          >
            Start Trading Now <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
}