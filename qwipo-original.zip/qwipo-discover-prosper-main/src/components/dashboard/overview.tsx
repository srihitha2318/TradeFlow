import { StatCard } from "@/components/ui/stat-card";
import { MetricChart } from "@/components/ui/metric-chart";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  Users, 
  ShoppingCart, 
  Target,
  ArrowRight,
  AlertCircle,
  CheckCircle
} from "lucide-react";

export function Overview() {
  const keyMetrics = [
    {
      title: "Active Retailers",
      value: "2,847",
      change: "+12% from last month",
      changeType: "positive" as const,
      icon: <Users className="h-5 w-5" />
    },
    {
      title: "Average Order Value",
      value: "₹18,240",
      change: "+18% increase",
      changeType: "positive" as const,
      icon: <ShoppingCart className="h-5 w-5" />
    },
    {
      title: "Recommendation Accuracy",
      value: "87.3%",
      change: "+5.2% improvement",
      changeType: "positive" as const,
      icon: <Target className="h-5 w-5" />
    },
    {
      title: "Repeat Purchase Rate",
      value: "64.8%",
      change: "+25% increase",
      changeType: "positive" as const,
      icon: <TrendingUp className="h-5 w-5" />
    }
  ];

  const categoryData = [
    { label: "Food & Beverages", value: 2340 },
    { label: "Household Items", value: 1890 },
    { label: "Personal Care", value: 1456 },
    { label: "Electronics", value: 987 },
    { label: "Apparel", value: 756 }
  ];

  const regionData = [
    { label: "Mumbai", value: 1234 },
    { label: "Delhi", value: 1089 },
    { label: "Bangalore", value: 967 },
    { label: "Chennai", value: 845 },
    { label: "Kolkata", value: 723 }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard Overview</h1>
          <p className="text-muted-foreground">
            Real-time insights into your B2B marketplace performance
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">Export Report</Button>
          <Button variant="hero">View Analytics</Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {keyMetrics.map((metric, index) => (
          <StatCard
            key={index}
            title={metric.title}
            value={metric.value}
            change={metric.change}
            changeType={metric.changeType}
            icon={metric.icon}
          />
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 md:grid-cols-2">
        <MetricChart
          title="Top Product Categories"
          data={categoryData}
        />
        <MetricChart
          title="Regional Performance"
          data={regionData}
        />
      </div>

      {/* Recent Activity & Recommendations */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-lg border bg-card p-6 shadow-card">
          <h3 className="text-lg font-semibold text-card-foreground mb-4">Recent Activities</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-accent mt-0.5" />
              <div>
                <p className="text-sm font-medium text-card-foreground">New recommendation model deployed</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
              <div>
                <p className="text-sm font-medium text-card-foreground">Low inventory alert for 23 retailers</p>
                <p className="text-xs text-muted-foreground">4 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-accent mt-0.5" />
              <div>
                <p className="text-sm font-medium text-card-foreground">Weekly performance report generated</p>
                <p className="text-xs text-muted-foreground">1 day ago</p>
              </div>
            </div>
          </div>
          <Button variant="ghost" className="mt-4 w-full">
            View All Activities
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-card">
          <h3 className="text-lg font-semibold text-card-foreground mb-4">System Insights</h3>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-gradient-subtle border">
              <h4 className="font-medium text-card-foreground mb-2">Peak Performance Hour</h4>
              <p className="text-sm text-muted-foreground">
                Recommendation engine shows highest accuracy between 2-4 PM daily
              </p>
            </div>
            <div className="p-4 rounded-lg bg-accent/10 border border-accent/20">
              <h4 className="font-medium text-card-foreground mb-2">Opportunity Identified</h4>
              <p className="text-sm text-muted-foreground">
                450+ retailers showing high cross-sell potential in electronics category
              </p>
            </div>
          </div>
          <Button variant="accent" className="mt-4 w-full">
            Explore Insights
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}