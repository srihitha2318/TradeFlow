import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { StatCard } from "@/components/ui/stat-card";
import { AdvancedFilters } from "@/components/filters/advanced-filters";
import { 
  Search, 
  Filter, 
  ShoppingCart, 
  Heart, 
  Star, 
  Users, 
  ShoppingBag, 
  TrendingUp,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  ArrowLeft,
  Plus,
  Camera,
  Image as ImageIcon
} from "lucide-react";

interface CustomerDashboardProps {
  onBack: () => void;
}

export function CustomerDashboard({ onBack }: CustomerDashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentFeedback, setCurrentFeedback] = useState(0);
  const [showChatbot, setShowChatbot] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { sender: "bot", message: "Hello! How can I help you find the right products for your business?" }
  ]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [cartItems, setCartItems] = useState<string[]>([]);

  const products = [
    {
      id: "1",
      name: "Premium Cotton T-Shirts",
      price: "₹299",
      bulkPrice: "₹249/piece (Min 100)",
      image: "/placeholder.svg",
      supplier: "Fashion Hub India",
      rating: 4.5,
      reviews: 234,
      category: "Clothing",
      inStock: true,
      moq: "100 pieces"
    },
    {
      id: "2",
      name: "Wireless Bluetooth Headphones",
      price: "₹1,499",
      bulkPrice: "₹1,299/piece (Min 50)",
      image: "/placeholder.svg",
      supplier: "TechWorld Electronics",
      rating: 4.3,
      reviews: 189,
      category: "Electronics",
      inStock: true,
      moq: "50 pieces"
    },
    {
      id: "3",
      name: "Stainless Steel Water Bottles",
      price: "₹399",
      bulkPrice: "₹299/piece (Min 200)",
      image: "/placeholder.svg",
      supplier: "EcoLife Products",
      rating: 4.7,
      reviews: 456,
      category: "Home & Kitchen",
      inStock: false,
      moq: "200 pieces"
    },
    {
      id: "4",
      name: "Organic Green Tea",
      price: "₹799",
      bulkPrice: "₹649/kg (Min 25kg)",
      image: "/placeholder.svg",
      supplier: "Pure Organics",
      rating: 4.6,
      reviews: 123,
      category: "Food & Beverages",
      inStock: true,
      moq: "25 kg"
    },
    {
      id: "5",
      name: "LED Desk Lamps",
      price: "₹899",
      bulkPrice: "₹749/piece (Min 30)",
      image: "/placeholder.svg",
      supplier: "BrightLight Solutions",
      rating: 4.4,
      reviews: 78,
      category: "Electronics",
      inStock: true,
      moq: "30 pieces"
    },
    {
      id: "6",
      name: "Handcrafted Wooden Boxes",
      price: "₹199",
      bulkPrice: "₹149/piece (Min 500)",
      image: "/placeholder.svg",
      supplier: "Artisan Crafts",
      rating: 4.8,
      reviews: 345,
      category: "Home Decor",
      inStock: true,
      moq: "500 pieces"
    },
    {
      id: "7",
      name: "Yoga Mats",
      price: "₹599",
      bulkPrice: "₹499/piece (Min 100)",
      image: "/placeholder.svg",
      supplier: "FitLife Sports",
      rating: 4.5,
      reviews: 156,
      category: "Sports",
      inStock: true,
      moq: "100 pieces"
    },
    {
      id: "8",
      name: "Office Notebooks",
      price: "₹49",
      bulkPrice: "₹39/piece (Min 1000)",
      image: "/placeholder.svg",
      supplier: "Paper Plus",
      rating: 4.2,
      reviews: 267,
      category: "Stationery",
      inStock: true,
      moq: "1000 pieces"
    },
    {
      id: "9",
      name: "Ceramic Coffee Mugs",
      price: "₹149",
      bulkPrice: "₹119/piece (Min 200)",
      image: "/placeholder.svg",
      supplier: "Kitchen Essentials",
      rating: 4.6,
      reviews: 89,
      category: "Home & Kitchen",
      inStock: true,
      moq: "200 pieces"
    },
    {
      id: "10",
      name: "Smart Watches",
      price: "₹2,999",
      bulkPrice: "₹2,599/piece (Min 25)",
      image: "/placeholder.svg",
      supplier: "TechGear Pro",
      rating: 4.4,
      reviews: 134,
      category: "Electronics",
      inStock: true,
      moq: "25 pieces"
    },
    {
      id: "11",
      name: "Plastic Storage Boxes",
      price: "₹199",
      bulkPrice: "₹159/piece (Min 300)",
      image: "/placeholder.svg",
      supplier: "Home Storage Co",
      rating: 4.3,
      reviews: 298,
      category: "Home & Kitchen",
      inStock: true,
      moq: "300 pieces"
    },
    {
      id: "12",
      name: "Face Masks (Pack of 50)",
      price: "₹299",
      bulkPrice: "₹249/pack (Min 100 packs)",
      image: "/placeholder.svg",
      supplier: "HealthCare Supplies",
      rating: 4.7,
      reviews: 445,
      category: "Healthcare",
      inStock: true,
      moq: "100 packs"
    }
  ];

  const sendMessage = () => {
    if (currentMessage.trim()) {
      setChatMessages(prev => [...prev, { sender: "user", message: currentMessage }]);
      // Simulate AI response based on user query
      setTimeout(() => {
        let response = "";
        const query = currentMessage.toLowerCase();
        
        if (query.includes("product") || query.includes("find")) {
          response = "I can help you find products! Try searching by category like 'electronics', 'clothing', or 'home & kitchen'. You can also use our advanced filters for more specific requirements.";
        } else if (query.includes("price") || query.includes("cost")) {
          response = "All our products have bulk pricing options with significant discounts. The minimum order quantities vary by product. Would you like me to show you products in a specific price range?";
        } else if (query.includes("supplier") || query.includes("seller")) {
          response = "We work with verified suppliers across India. You can filter by top-rated sellers or verified suppliers in our advanced search. All our suppliers are vetted for quality and reliability.";
        } else if (query.includes("shipping") || query.includes("delivery")) {
          response = "Shipping options vary by supplier and location. Many of our suppliers offer free shipping for bulk orders. You can filter products by shipping options in our advanced filters.";
        } else {
          response = "I'm here to help you with product discovery, pricing information, supplier details, and any other questions about our marketplace. What specific products are you looking for?";
        }
        
        setChatMessages(prev => [...prev, { 
          sender: "bot", 
          message: response
        }]);
      }, 1000);
      setCurrentMessage("");
    }
  };

  const addToCart = (productId: string) => {
    if (!cartItems.includes(productId)) {
      setCartItems(prev => [...prev, productId]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-background/95 backdrop-blur border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Trade Flow</h1>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 h-5 w-5 bg-accent text-accent-foreground text-xs rounded-full flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search and Filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search for products, suppliers, or categories..."
                className="pl-10 pr-16 py-3 text-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Camera className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <ImageIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="lg:w-auto"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Advanced Filters */}
        <AdvancedFilters isOpen={showFilters} onClose={() => setShowFilters(false)} />

        {/* Main Content */}
        <div className="space-y-8">
          {/* Categories */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Shop by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
              {["Electronics", "Clothing", "Food & Beverages", "Home & Kitchen", "Healthcare", "Stationery", "Sports", "Home Decor"].map((category) => (
                <Card key={category} className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
                  <ShoppingBag className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="font-medium text-sm">{category}</p>
                </Card>
              ))}
            </div>
          </div>

          {/* Products */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Featured Products</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 bg-background/80 hover:bg-background"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                    {!product.inStock && (
                      <Badge variant="destructive" className="absolute top-2 left-2">
                        Out of Stock
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.name}</h3>
                    <div className="flex items-center gap-1 mb-2">
                      <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                      <span className="text-sm font-medium">{product.rating}</span>
                      <span className="text-sm text-muted-foreground">({product.reviews})</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{product.supplier}</p>
                    <div className="space-y-1 mb-3">
                      <p className="text-lg font-bold text-primary">{product.bulkPrice}</p>
                      <p className="text-sm text-muted-foreground line-through">{product.price}</p>
                      <p className="text-xs text-muted-foreground">MOQ: {product.moq}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => addToCart(product.id)}
                      >
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        {cartItems.includes(product.id) ? "Added to Cart" : "Add to Cart"}
                      </Button>
                      <Button 
                        variant="default" 
                        className="flex-1"
                      >
                        Buy Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* AI Chatbot */}
        {showChatbot && (
          <div className="fixed bottom-20 right-4 w-80 h-96 bg-background border rounded-lg shadow-lg z-50">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">AI Assistant</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowChatbot(false)}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="p-4 h-64 overflow-y-auto space-y-3">
              {chatMessages.map((msg, index) => (
                <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs p-3 rounded-lg ${
                    msg.sender === 'user' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-foreground'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything..."
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                />
                <Button onClick={sendMessage}>Send</Button>
              </div>
            </div>
          </div>
        )}

        {/* Floating Chat Button */}
        <Button
          className="fixed bottom-4 right-4 h-12 w-12 rounded-full shadow-lg z-40"
          onClick={() => setShowChatbot(!showChatbot)}
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}