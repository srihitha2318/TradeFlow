import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { StatCard } from "@/components/ui/stat-card";
import { 
  ArrowLeft, 
  Package, 
  TrendingUp, 
  Users, 
  Star,
  Plus,
  Edit,
  AlertTriangle,
  CheckCircle,
  MessageCircle
} from "lucide-react";

interface SupplierDashboardProps {
  onBack: () => void;
}

export function SupplierDashboard({ onBack }: SupplierDashboardProps) {
  const [showChatbot, setShowChatbot] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { sender: "bot", message: "Hello! How can I help you manage your inventory and orders today?" }
  ]);
  const [currentMessage, setCurrentMessage] = useState("");

  const stats = [
    { title: "Total Products", value: "156", icon: Package, trend: "+12" },
    { title: "Total Orders", value: "2,847", icon: TrendingUp, trend: "+23%" },
    { title: "Active Customers", value: "489", icon: Users, trend: "+8%" },
    { title: "Average Rating", value: "4.7", icon: Star, trend: "+0.2" }
  ];

  const products = [
    {
      id: "1",
      name: "Premium Cotton T-Shirts",
      stock: 2500,
      price: "₹249",
      orders: 45,
      status: "in_stock",
      image: "/placeholder.svg"
    },
    {
      id: "2",
      name: "Wireless Bluetooth Headphones",
      stock: 150,
      price: "₹1,299",
      orders: 23,
      status: "low_stock",
      image: "/placeholder.svg"
    },
    {
      id: "3",
      name: "Stainless Steel Water Bottles",
      stock: 0,
      price: "₹299",
      orders: 67,
      status: "out_of_stock",
      image: "/placeholder.svg"
    },
    {
      id: "4",
      name: "Organic Green Tea",
      stock: 800,
      price: "₹649",
      orders: 34,
      status: "in_stock",
      image: "/placeholder.svg"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_stock":
        return <Badge className="bg-green-100 text-green-800">In Stock</Badge>;
      case "low_stock":
        return <Badge className="bg-yellow-100 text-yellow-800">Low Stock</Badge>;
      case "out_of_stock":
        return <Badge className="bg-red-100 text-red-800">Out of Stock</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "in_stock":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "low_stock":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case "out_of_stock":
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const sendMessage = () => {
    if (currentMessage.trim()) {
      setChatMessages(prev => [...prev, { sender: "user", message: currentMessage }]);
      setTimeout(() => {
        let response = "";
        const query = currentMessage.toLowerCase();
        
        if (query.includes("inventory") || query.includes("stock")) {
          response = "I can help you manage your inventory! You can update stock levels, add new products, or set low stock alerts. Would you like me to guide you through any specific inventory task?";
        } else if (query.includes("order") || query.includes("sale")) {
          response = "You have 156 total products with 2,847 orders this month. Your top-selling items need restocking. Would you like to see your order analytics or update product availability?";
        } else if (query.includes("customer") || query.includes("buyer")) {
          response = "You have 489 active customers with an average rating of 4.7 stars. I can help you manage customer relationships and track buyer preferences.";
        } else {
          response = "I'm here to help you with inventory management, order processing, customer analytics, and product optimization. What would you like to work on?";
        }
        
        setChatMessages(prev => [...prev, { 
          sender: "bot", 
          message: response
        }]);
      }, 1000);
      setCurrentMessage("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-background/95 backdrop-blur border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Supplier Dashboard</h1>
            </div>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add New Product
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <StatCard
              key={index}
              title={stat.title}
              value={stat.value}
              icon={<stat.icon className="h-6 w-6" />}
            />
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Manage your business efficiently</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-20 flex-col">
                <Plus className="h-6 w-6 mb-2" />
                Add Product
              </Button>
              <Button variant="outline" className="h-20 flex-col">
                <Package className="h-6 w-6 mb-2" />
                Update Inventory
              </Button>
              <Button variant="outline" className="h-20 flex-col">
                <TrendingUp className="h-6 w-6 mb-2" />
                View Analytics
              </Button>
              <Button variant="outline" className="h-20 flex-col">
                <Users className="h-6 w-6 mb-2" />
                Customer Orders
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Products Inventory */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Product Inventory</CardTitle>
                <CardDescription>Manage your bulk goods and stock levels</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add New Product
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-40 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-2 right-2 flex items-center gap-1">
                      {getStatusIcon(product.status)}
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.name}</h3>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Stock:</span>
                        <span className="font-medium">{product.stock} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Price:</span>
                        <span className="font-medium text-primary">{product.price}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Orders:</span>
                        <span className="font-medium">{product.orders}</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-muted-foreground">Status:</span>
                      {getStatusBadge(product.status)}
                    </div>
                    <Button variant="outline" className="w-full">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Product
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AI Chatbot */}
        {showChatbot && (
          <div className="fixed bottom-20 right-4 w-80 h-96 bg-background border rounded-lg shadow-lg z-50">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">AI Assistant</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowChatbot(false)}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="p-4 h-64 overflow-y-auto space-y-3">
              {chatMessages.map((msg, index) => (
                <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs p-3 rounded-lg ${
                    msg.sender === 'user' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-foreground'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything..."
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                />
                <Button onClick={sendMessage}>Send</Button>
              </div>
            </div>
          </div>
        )}

        {/* Floating Chat Button */}
        <Button
          className="fixed bottom-4 right-4 h-12 w-12 rounded-full shadow-lg z-40"
          onClick={() => setShowChatbot(!showChatbot)}
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}