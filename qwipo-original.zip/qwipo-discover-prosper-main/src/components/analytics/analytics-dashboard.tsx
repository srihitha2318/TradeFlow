import { StatCard } from "@/components/ui/stat-card";
import { MetricChart } from "@/components/ui/metric-chart";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Clock,
  Download,
  Calendar,
  Filter
} from "lucide-react";

export function AnalyticsDashboard() {
  const performanceMetrics = [
    {
      title: "API Response Time",
      value: "142ms",
      change: "-15ms improvement",
      changeType: "positive" as const,
      icon: <Clock className="h-5 w-5" />
    },
    {
      title: "Concurrent Users",
      value: "8,234",
      change: "+1,245 peak today",
      changeType: "positive" as const,
      icon: <Users className="h-5 w-5" />
    },
    {
      title: "Uptime",
      value: "99.97%",
      change: "Above target",
      changeType: "positive" as const,
      icon: <TrendingUp className="h-5 w-5" />
    },
    {
      title: "Data Processed",
      value: "2.4TB",
      change: "+340GB today",
      changeType: "positive" as const,
      icon: <BarChart3 className="h-5 w-5" />
    }
  ];

  const hourlyData = [
    { label: "00:00", value: 1200 },
    { label: "04:00", value: 800 },
    { label: "08:00", value: 2400 },
    { label: "12:00", value: 3600 },
    { label: "16:00", value: 4200 },
    { label: "20:00", value: 2800 }
  ];

  const categoryEngagement = [
    { label: "Food & Beverages", value: 4500 },
    { label: "Personal Care", value: 3200 },
    { label: "Electronics", value: 2800 },
    { label: "Household", value: 2100 },
    { label: "Apparel", value: 1600 }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Deep insights into user behavior and system performance
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Date Range
          </Button>
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button variant="hero">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {performanceMetrics.map((metric, index) => (
          <StatCard
            key={index}
            title={metric.title}
            value={metric.value}
            change={metric.change}
            changeType={metric.changeType}
            icon={metric.icon}
          />
        ))}
      </div>

      {/* Detailed Analytics */}
      <div className="grid gap-6 md:grid-cols-2">
        <MetricChart
          title="Hourly User Activity"
          data={hourlyData}
        />
        <MetricChart
          title="Category Engagement"
          data={categoryEngagement}
        />
      </div>

      {/* Purchase Patterns */}
      <div className="rounded-lg border bg-card p-6 shadow-card">
        <h2 className="text-xl font-semibold text-card-foreground mb-4">Purchase Pattern Analysis</h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="space-y-4">
            <h3 className="font-medium text-card-foreground">Seasonal Trends</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Summer Products</span>
                <Badge variant="secondary">+24%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Monsoon Essentials</span>
                <Badge variant="secondary">+18%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Festival Items</span>
                <Badge variant="secondary">+42%</Badge>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium text-card-foreground">Repeat Orders</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Weekly Cycles</span>
                <Badge variant="outline">67%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Monthly Patterns</span>
                <Badge variant="outline">84%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Loyalty Rate</span>
                <Badge variant="outline">91%</Badge>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium text-card-foreground">Cross-selling</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Bundle Success</span>
                <Badge className="bg-accent text-accent-foreground">73%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Upsell Rate</span>
                <Badge className="bg-accent text-accent-foreground">45%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">AOV Increase</span>
                <Badge className="bg-accent text-accent-foreground">+₹1,240</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}