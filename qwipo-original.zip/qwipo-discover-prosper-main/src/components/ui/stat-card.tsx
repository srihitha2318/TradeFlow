import * as React from "react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  icon?: React.ReactNode;
  className?: string;
}

const StatCard = React.forwardRef<HTMLDivElement, StatCardProps>(
  ({ title, value, change, changeType = "neutral", icon, className, ...props }, ref) => {
    const getChangeColor = () => {
      switch (changeType) {
        case "positive":
          return "text-accent";
        case "negative":
          return "text-destructive";
        default:
          return "text-muted-foreground";
      }
    };

    return (
      <div
        ref={ref}
        className={cn(
          "rounded-lg border bg-card p-6 shadow-card transition-all duration-300 hover:shadow-elegant",
          className
        )}
        {...props}
      >
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-card-foreground">{value}</p>
            {change && (
              <p className={cn("text-xs font-medium", getChangeColor())}>
                {change}
              </p>
            )}
          </div>
          {icon && (
            <div className="text-primary opacity-80">
              {icon}
            </div>
          )}
        </div>
      </div>
    );
  }
);

StatCard.displayName = "StatCard";

export { StatCard };