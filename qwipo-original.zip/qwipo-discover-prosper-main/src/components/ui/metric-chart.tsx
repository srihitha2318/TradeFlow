import * as React from "react";
import { cn } from "@/lib/utils";

interface DataPoint {
  label: string;
  value: number;
}

interface MetricChartProps {
  title: string;
  data: DataPoint[];
  className?: string;
}

const MetricChart = React.forwardRef<HTMLDivElement, MetricChartProps>(
  ({ title, data, className, ...props }, ref) => {
    const maxValue = Math.max(...data.map(d => d.value));

    return (
      <div
        ref={ref}
        className={cn(
          "rounded-lg border bg-card p-6 shadow-card",
          className
        )}
        {...props}
      >
        <h3 className="text-lg font-semibold text-card-foreground mb-4">{title}</h3>
        <div className="space-y-3">
          {data.map((item, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{item.label}</span>
                <span className="font-medium text-card-foreground">{item.value}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-primary rounded-full transition-all duration-500"
                  style={{ width: `${(item.value / maxValue) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
);

MetricChart.displayName = "MetricChart";

export { MetricChart };