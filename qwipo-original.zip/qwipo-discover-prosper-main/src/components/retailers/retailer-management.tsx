import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Store, 
  TrendingUp, 
  AlertCircle,
  Search,
  Filter,
  UserPlus,
  MapPin,
  Phone,
  Mail
} from "lucide-react";

export function RetailerManagement() {
  const retailerStats = [
    {
      title: "Total Retailers",
      value: "2,847",
      change: "+124 this month",
      changeType: "positive" as const,
      icon: <Store className="h-5 w-5" />
    },
    {
      title: "Active This Week",
      value: "2,156",
      change: "76% active rate",
      changeType: "positive" as const,
      icon: <Users className="h-5 w-5" />
    },
    {
      title: "New Registrations",
      value: "89",
      change: "+23% from last week",
      changeType: "positive" as const,
      icon: <TrendingUp className="h-5 w-5" />
    },
    {
      title: "At Risk",
      value: "156",
      change: "Need attention",
      changeType: "negative" as const,
      icon: <AlertCircle className="h-5 w-5" />
    }
  ];

  const retailers = [
    {
      id: "R001",
      name: "Krishna General Store",
      owner: "Ramesh Kumar",
      location: "Mumbai, Maharashtra",
      category: "Kirana Store",
      status: "Active",
      lastOrder: "2 hours ago",
      aov: "₹18,450",
      phone: "+91 98765 43210",
      email: "ramesh@kgs.com",
      riskLevel: "Low"
    },
    {
      id: "R002",
      name: "Metro Mart",
      owner: "Priya Singh",
      location: "Delhi, NCR",
      category: "Supermarket",
      status: "Active",
      lastOrder: "1 day ago",
      aov: "₹24,670",
      phone: "+91 98765 43211",
      email: "priya@metromart.com",
      riskLevel: "Low"
    },
    {
      id: "R003",
      name: "City Electronics",
      owner: "Amit Patel",
      location: "Bangalore, Karnataka",
      category: "Electronics",
      status: "Inactive",
      lastOrder: "15 days ago",
      aov: "₹12,340",
      phone: "+91 98765 43212",
      email: "amit@cityelectronics.com",
      riskLevel: "High"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Active":
        return <Badge className="bg-accent text-accent-foreground">Active</Badge>;
      case "Inactive":
        return <Badge variant="destructive">Inactive</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "Low":
        return <Badge variant="outline" className="border-accent text-accent">Low Risk</Badge>;
      case "High":
        return <Badge variant="outline" className="border-destructive text-destructive">High Risk</Badge>;
      default:
        return <Badge variant="outline">Medium Risk</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Retailer Management</h1>
          <p className="text-muted-foreground">
            Manage and monitor your B2B retail partners
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="hero">
            <UserPlus className="h-4 w-4 mr-2" />
            Add Retailer
          </Button>
        </div>
      </div>

      {/* Retailer Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {retailerStats.map((stat, index) => (
          <StatCard
            key={index}
            title={stat.title}
            value={stat.value}
            change={stat.change}
            changeType={stat.changeType}
            icon={stat.icon}
          />
        ))}
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <input
            type="text"
            placeholder="Search retailers by name, location, or category..."
            className="w-full pl-10 pr-4 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <select className="px-4 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring">
          <option>All Categories</option>
          <option>Kirana Store</option>
          <option>Supermarket</option>
          <option>Electronics</option>
          <option>Restaurant</option>
        </select>
      </div>

      {/* Retailer List */}
      <div className="rounded-lg border bg-card shadow-card">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold text-card-foreground">Active Retailers</h2>
        </div>
        
        <div className="divide-y">
          {retailers.map((retailer) => (
            <div key={retailer.id} className="p-6 hover:bg-muted/50 transition-colors">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-gradient-primary flex items-center justify-center">
                      <Store className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-card-foreground">{retailer.name}</h3>
                        {getStatusBadge(retailer.status)}
                        {getRiskBadge(retailer.riskLevel)}
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{retailer.owner} • {retailer.category}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {retailer.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {retailer.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {retailer.email}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 lg:gap-6">
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground">Last Order</p>
                    <p className="text-sm font-medium text-card-foreground">{retailer.lastOrder}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground">Avg Order Value</p>
                    <p className="text-sm font-medium text-card-foreground">{retailer.aov}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">View Profile</Button>
                    <Button variant="default" size="sm">Send Recommendations</Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}