import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { X, Filter } from "lucide-react";

interface AdvancedFiltersProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AdvancedFilters({ isOpen, onClose }: AdvancedFiltersProps) {
  const [filters, setFilters] = useState({
    category: "",
    subcategory: "",
    brand: "",
    priceRange: [0, 100000],
    moq: "",
    inStock: false,
    freeShipping: false,
    verifiedSupplier: false,
    topRated: false,
    newArrivals: false,
    onSale: false,
    certification: "",
    material: "",
    color: "",
    weight: "",
    leadTime: "",
    businessType: "",
    countryOrigin: "",
    warranty: false,
    ecoFriendly: false,
    bulkDiscount: false,
  });

  const categories = [
    "Electronics", "Clothing & Textiles", "Food & Beverages", "Machinery", 
    "Chemicals", "Automotive", "Home & Garden", "Sports & Recreation"
  ];

  const brands = [
    "Samsung", "Apple", "Nike", "Adidas", "Sony", "LG", "Bosch", "Siemens"
  ];

  const certifications = [
    "ISO 9001", "ISO 14001", "FDA", "CE", "ROHS", "FCC", "UL", "BIS"
  ];

  const businessTypes = [
    "Manufacturer", "Wholesaler", "Distributor", "Trading Company", "Agent"
  ];

  const countries = [
    "India", "China", "USA", "Germany", "Japan", "South Korea", "Italy", "UK"
  ];

  const activeFiltersCount = Object.values(filters).filter(value => {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'string') return value !== '';
    if (Array.isArray(value)) return value[0] !== 0 || value[1] !== 100000;
    return false;
  }).length;

  const clearAllFilters = () => {
    setFilters({
      category: "",
      subcategory: "",
      brand: "",
      priceRange: [0, 100000],
      moq: "",
      inStock: false,
      freeShipping: false,
      verifiedSupplier: false,
      topRated: false,
      newArrivals: false,
      onSale: false,
      certification: "",
      material: "",
      color: "",
      weight: "",
      leadTime: "",
      businessType: "",
      countryOrigin: "",
      warranty: false,
      ecoFriendly: false,
      bulkDiscount: false,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Advanced Filters
            {activeFiltersCount > 0 && (
              <Badge variant="secondary">{activeFiltersCount} active</Badge>
            )}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Product Information Filters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Product Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={filters.category} onValueChange={(value) => setFilters({...filters, category: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="brand">Brand/Manufacturer</Label>
                <Select value={filters.brand} onValueChange={(value) => setFilters({...filters, brand: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select brand" />
                  </SelectTrigger>
                  <SelectContent>
                    {brands.map(brand => (
                      <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="material">Material/Composition</Label>
                <Input 
                  placeholder="e.g., Cotton, Steel, Plastic"
                  value={filters.material}
                  onChange={(e) => setFilters({...filters, material: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="color">Color</Label>
                <Input 
                  placeholder="e.g., Red, Blue, Black"
                  value={filters.color}
                  onChange={(e) => setFilters({...filters, color: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="weight">Weight/Volume</Label>
                <Input 
                  placeholder="e.g., 1kg, 500ml"
                  value={filters.weight}
                  onChange={(e) => setFilters({...filters, weight: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* Pricing & Quantity Filters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Pricing & Quantity</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label>Price Range (₹)</Label>
                <div className="px-2 py-4">
                  <Slider
                    value={filters.priceRange}
                    onValueChange={(value) => setFilters({...filters, priceRange: value})}
                    max={100000}
                    min={0}
                    step={1000}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-2">
                    <span>₹{filters.priceRange[0].toLocaleString()}</span>
                    <span>₹{filters.priceRange[1].toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="moq">Minimum Order Quantity</Label>
                <Input 
                  placeholder="e.g., 100 pieces"
                  value={filters.moq}
                  onChange={(e) => setFilters({...filters, moq: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Quantity Options</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="bulkDiscount" 
                      checked={filters.bulkDiscount}
                      onCheckedChange={(checked) => setFilters({...filters, bulkDiscount: checked as boolean})}
                    />
                    <Label htmlFor="bulkDiscount">Bulk Discount Available</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Availability & Shipping Filters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Availability & Shipping</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Stock Status</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="inStock" 
                      checked={filters.inStock}
                      onCheckedChange={(checked) => setFilters({...filters, inStock: checked as boolean})}
                    />
                    <Label htmlFor="inStock">In Stock Only</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="freeShipping" 
                      checked={filters.freeShipping}
                      onCheckedChange={(checked) => setFilters({...filters, freeShipping: checked as boolean})}
                    />
                    <Label htmlFor="freeShipping">Free Shipping</Label>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="leadTime">Lead Time/Delivery Time</Label>
                <Select value={filters.leadTime} onValueChange={(value) => setFilters({...filters, leadTime: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select lead time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-3days">1-3 Days</SelectItem>
                    <SelectItem value="4-7days">4-7 Days</SelectItem>
                    <SelectItem value="1-2weeks">1-2 Weeks</SelectItem>
                    <SelectItem value="3-4weeks">3-4 Weeks</SelectItem>
                    <SelectItem value="1month+">1 Month+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Seller/Supplier Filters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Seller/Supplier</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Supplier Quality</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="verifiedSupplier" 
                      checked={filters.verifiedSupplier}
                      onCheckedChange={(checked) => setFilters({...filters, verifiedSupplier: checked as boolean})}
                    />
                    <Label htmlFor="verifiedSupplier">Verified Supplier</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="topRated" 
                      checked={filters.topRated}
                      onCheckedChange={(checked) => setFilters({...filters, topRated: checked as boolean})}
                    />
                    <Label htmlFor="topRated">Top-rated Seller</Label>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="businessType">Business Type</Label>
                <Select value={filters.businessType} onValueChange={(value) => setFilters({...filters, businessType: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="countryOrigin">Country/Region</Label>
                <Select value={filters.countryOrigin} onValueChange={(value) => setFilters({...filters, countryOrigin: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map(country => (
                      <SelectItem key={country} value={country}>{country}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Compliance & Standards */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Compliance & Standards</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="certification">Certifications</Label>
                <Select value={filters.certification} onValueChange={(value) => setFilters({...filters, certification: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select certification" />
                  </SelectTrigger>
                  <SelectContent>
                    {certifications.map(cert => (
                      <SelectItem key={cert} value={cert}>{cert}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quality Standards</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="ecoFriendly" 
                      checked={filters.ecoFriendly}
                      onCheckedChange={(checked) => setFilters({...filters, ecoFriendly: checked as boolean})}
                    />
                    <Label htmlFor="ecoFriendly">Eco-Friendly/Sustainable</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="warranty" 
                      checked={filters.warranty}
                      onCheckedChange={(checked) => setFilters({...filters, warranty: checked as boolean})}
                    />
                    <Label htmlFor="warranty">Warranty/Guarantee</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Promotions & Deals */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Promotions & Deals</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Special Offers</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="onSale" 
                      checked={filters.onSale}
                      onCheckedChange={(checked) => setFilters({...filters, onSale: checked as boolean})}
                    />
                    <Label htmlFor="onSale">On Sale/Discounted</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="newArrivals" 
                      checked={filters.newArrivals}
                      onCheckedChange={(checked) => setFilters({...filters, newArrivals: checked as boolean})}
                    />
                    <Label htmlFor="newArrivals">New Arrivals</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between pt-6 border-t">
            <Button variant="outline" onClick={clearAllFilters}>
              Clear All
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={onClose}>
                Apply Filters ({activeFiltersCount})
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}