import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/ui/stat-card";
import { Badge } from "@/components/ui/badge";
import { 
  Target, 
  Brain, 
  TrendingUp, 
  Users,
  Filter,
  ArrowRight,
  Star,
  ShoppingCart
} from "lucide-react";

export function RecommendationEngine() {
  const recommendations = [
    {
      retailer: "Krishna General Store",
      category: "Personal Care",
      products: ["Colgate Toothpaste", "Head & Shoulders Shampoo", "Dettol Soap"],
      confidence: 94,
      potentialValue: "₹2,450",
      reason: "High correlation with similar retailers"
    },
    {
      retailer: "Metro Mart",
      category: "Food & Beverages",
      products: ["Maggi Noodles", "Coca Cola", "Parle Biscuits"],
      confidence: 89,
      potentialValue: "₹3,240",
      reason: "Seasonal trend analysis"
    },
    {
      retailer: "City Electronics",
      category: "Electronics",
      products: ["Samsung Charger", "Power Bank", "Bluetooth Speaker"],
      confidence: 92,
      potentialValue: "₹5,670",
      reason: "Purchase history pattern"
    }
  ];

  const metrics = [
    {
      title: "Recommendations Generated",
      value: "15,247",
      change: "+8% from yesterday",
      changeType: "positive" as const,
      icon: <Target className="h-5 w-5" />
    },
    {
      title: "Acceptance Rate",
      value: "73.2%",
      change: "+12% improvement",
      changeType: "positive" as const,
      icon: <Brain className="h-5 w-5" />
    },
    {
      title: "Revenue Impact",
      value: "₹2.4M",
      change: "+22% increase",
      changeType: "positive" as const,
      icon: <TrendingUp className="h-5 w-5" />
    },
    {
      title: "Engaged Retailers",
      value: "1,847",
      change: "+156 new users",
      changeType: "positive" as const,
      icon: <Users className="h-5 w-5" />
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Recommendation Engine</h1>
          <p className="text-muted-foreground">
            AI-powered product suggestions to boost retailer success
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="hero">Generate New Batch</Button>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {metrics.map((metric, index) => (
          <StatCard
            key={index}
            title={metric.title}
            value={metric.value}
            change={metric.change}
            changeType={metric.changeType}
            icon={metric.icon}
          />
        ))}
      </div>

      {/* Active Recommendations */}
      <div className="rounded-lg border bg-card p-6 shadow-card">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-card-foreground">Active Recommendations</h2>
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            Live Updates
          </Badge>
        </div>

        <div className="space-y-4">
          {recommendations.map((rec, index) => (
            <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-all duration-300">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-card-foreground">{rec.retailer}</h3>
                  <p className="text-sm text-muted-foreground">{rec.category}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-1">
                    <Star className="h-4 w-4 text-warning fill-current" />
                    <span className="text-sm font-medium">{rec.confidence}%</span>
                  </div>
                  <p className="text-sm font-semibold text-accent">{rec.potentialValue}</p>
                </div>
              </div>

              <div className="mb-3">
                <p className="text-xs text-muted-foreground mb-2">Recommended Products:</p>
                <div className="flex flex-wrap gap-2">
                  {rec.products.map((product, pidx) => (
                    <Badge key={pidx} variant="outline" className="text-xs">
                      {product}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">
                  <Brain className="h-3 w-3 inline mr-1" />
                  {rec.reason}
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">View Details</Button>
                  <Button variant="default" size="sm">
                    <ShoppingCart className="h-3 w-3 mr-1" />
                    Send
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 text-center">
          <Button variant="ghost" className="w-full">
            Load More Recommendations
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}