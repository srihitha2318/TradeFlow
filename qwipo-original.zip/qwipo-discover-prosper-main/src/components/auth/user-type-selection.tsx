import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Package, ArrowLeft } from "lucide-react";

interface UserTypeSelectionProps {
  onSelectUserType: (type: "customer" | "supplier") => void;
  onBack: () => void;
}

export function UserTypeSelection({ onSelectUserType, onBack }: UserTypeSelectionProps) {
  return (
    <div className="min-h-screen bg-gradient-subtle flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <Button 
          variant="ghost" 
          onClick={onBack}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">
            Choose Your Account Type
          </h1>
          <p className="text-muted-foreground text-lg">
            Select how you want to use Trade Flow
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Customer Card */}
          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary">
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-2xl">I'm a Customer</CardTitle>
              <CardDescription className="text-base">
                Looking to purchase products in bulk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  Browse thousands of products
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  Get bulk pricing and discounts
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  AI-powered recommendations
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                  Connect with verified suppliers
                </li>
              </ul>
              <Button 
                className="w-full" 
                size="lg"
                onClick={() => onSelectUserType("customer")}
              >
                Continue as Customer
              </Button>
            </CardContent>
          </Card>

          {/* Supplier Card */}
          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary">
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="h-10 w-10 text-accent" />
              </div>
              <CardTitle className="text-2xl">I'm a Supplier</CardTitle>
              <CardDescription className="text-base">
                Looking to sell products in bulk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
                  List and manage your products
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
                  Reach thousands of buyers
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
                  Inventory management tools
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
                  Analytics and insights
                </li>
              </ul>
              <Button 
                className="w-full" 
                size="lg"
                variant="secondary"
                onClick={() => onSelectUserType("supplier")}
              >
                Continue as Supplier
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}